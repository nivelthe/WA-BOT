<img src="https://img.shields.io/badge/ISURUWA-WA--BOT-brightgreen?style=for-the-badge&logo=appveyor">

```
----- LOGS -----

* Recommand to deploy In Replit

```
<br>
<p align="center">
<img src="https://www.commbox.io/wp-content/uploads/2020/01/168-1.jpg">
<p align="center">
<a href="https://github.com/isuruwa"><img title="addon" src="https://img.shields.io/badge/isuruwa-WA--BOT-blueviolet?style=for-the-badge&logo=appveyor"></a>
<p align="center">
<img align="center" alt="visitors" src="https://visitor-badge.glitch.me/badge?page_id=isuruwawabot" />
<br>
<a href="https://hits.seeyoufarm.com"><img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2Fisuruwa&count_bg=%2379C83D&title_bg=%23555555&icon=&icon_color=%23E7E7E7&title=hits&edge_flat=false"/></a>
</p>
<br>
<p align="left">

<img src="https://img.shields.io/badge/isuruwa-ABOUT%20TOOL-blueviolet?style=for-the-badge&logo=appveyor">  

## ABOUT TOOL :  <img src="https://img.icons8.com/cute-clipart/50/000000/double-tick.png">
  
## I'm Not Adding Any API s like downloaders , because they are unstable . You can Add If you Like
  
## Only a Base of Basic Whatsapp Bot Redeveloped Using https://github.com/adiwajshing/Baileys & https://github.com/MhankBarBar/termux-wabot , https://github.com/HotarouTakahashi/Termux-Whatsapp-Bot-English Repo s . Add Your Own Functions & Redevelop It . 
  
  
# Tested On - Termux   <img src="https://img.icons8.com/cute-clipart/50/000000/double-tick.png">
 
  
<br>
  
  
## FIXED  <img src="https://img.icons8.com/cute-clipart/50/000000/double-tick.png">
  
👻 Fixed qr code not generating Error .
  
👻 Fixed Connecting Error .
  
👻 Fixed Module Errors.
  
👻 Removed Unecessary Modules & Redeveloped .
  
  
<br>
  
 ## FEATURES : <img src="https://img.icons8.com/cute-clipart/50/000000/double-tick.png">
  
 ## ADDED - 

  
  ✅convert video to mp3
  
 ✅ Send Photo with Caption
  
 ✅ Reply A Photo
  
 ✅ Reply A Video or GIF
  
 ✅ Send Video or GIF with Caption
  
 ✅ Reply A Sticker ( sticker to image )
  
 ✅ Image to Sticker / Video to gif
  
 ✅ Text to speech
  
 ✅ Take text in a picture
  
 ✅ Set Prefix
  
 ✅ Broadcast (bc/gm/gn)
  
  
  ## GROUP
  
  ✅ Tagall/Tagall2/Tagall3 Mentionall member
  
  ✅ Kick Members
  
  ✅ Add  Members
  
  ✅ Get a admins list
  
  ✅ Fetch Group Link 
  
  ✅ promote/demote members
  
  ✅ Block List
  
  ✅ open/close group
  
  
  
  
## INSTALLATION [Termux] [linux] : <img src="https://img.icons8.com/cute-clipart/50/000000/double-tick.png">
  
* `apt-get update -y`
* `apt-get upgrade -y`
* `apt install nodejs -y`
* `git clone https://github.com/isuruwa/WA-BOT`
* `cd WA-BOT`
* `bash install.sh`
* `npm start`
  
# Scan The Generated QR CODE & BOOM ... 👻
  
  
  
# SOURCES - https://github.com/adiwajshing/Baileys , https://github.com/MhankBarBar/termux-wabot  , https://github.com/HotarouTakahashi/Termux-Whatsapp-Bot-English
  
# Only basic Commands Included . Redevelop It as a yours .
  
  
<p align="center">
  
<img src="https://img.icons8.com/cute-clipart/256/000000/whatsapp.png"/>
  
  
# SCREENSHOTS : 
  
![Screenshot_20210627-181021_Termux_LI](https://user-images.githubusercontent.com/72663288/123545174-63793c80-d774-11eb-889b-61784367515c.jpg)

![Screenshot_20210627-181834_Termux_LI](https://user-images.githubusercontent.com/72663288/123545179-6b38e100-d774-11eb-898c-df1b3897db77.jpg)

![Screenshot_20210701-110146_FMWhatsApp](https://user-images.githubusercontent.com/72663288/124071136-8b122280-da5c-11eb-969c-2c1526598916.jpg)

  


  
  
