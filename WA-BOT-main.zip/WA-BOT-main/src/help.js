const help = (prefix) => {
	return `🤡 HELLO GUYS ! 🤡
	👻 I'm A BASIC WHATSAPP BOT REDEVELOPED BY DEVL MASTER 👻
	
❤  > User Commands < ❤
	
!sticker -  convert image/gif/video to sticker (reply to image/video)

!toimg -  convert sticker/gif to image (reply to sticker)

!tomp3 - Convert a video to mp3

!tts - convert text to audio |  !gtts [cc] [text]

!ocr -  Take the text in the picture

!setprefix - ${prefix}setprefix [text|optional]

!bc - Broadcast msg (bc/gm/gn)



💚 > Group Comands < 💚

!add -  add member into group

!kick - kick members from group

!promote - promote a member

!demote - demote a member

!clone - Clone a Target number profile pic to Yours 

!linkgroup - Get the group link

!listadmins - List Admins in group

!closegc - Close Group

!opengc - Open Group

!leave - Leave the bot from group

!tagall -  Tag All Members

!blocklist - List Of Blocked Numbers

!welcome - Activate Group Welcome

!clearall - Delete all chat

!info - About BOT


____________________________________

BOT REDEVELOPED BY DEVIL MASTER - https://github.com/isuruwa`
}

exports.help = help
